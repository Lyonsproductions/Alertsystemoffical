import { getStore } from "@netlify/blobs";
import { createHash, timingSafeEqual } from "node:crypto";

const ALERT_IDS = ["alice", "hold", "secure", "evac", "weather", "clear"];
const EMPTY = { alert: "clear", start: null, messages: [], rev: 0 };
const JSON_HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

const json = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: JSON_HEADERS });

// Compare passwords without leaking length or timing information.
function passwordOk(given) {
  const real = process.env.ADMIN_PASSWORD;
  if (!real || typeof given !== "string") return false;
  const a = createHash("sha256").update(given).digest();
  const b = createHash("sha256").update(real).digest();
  return timingSafeEqual(a, b);
}

// Never trust the browser: rebuild the state from known-good pieces only.
function clean(input, prevRev) {
  const alert = ALERT_IDS.includes(input?.alert) ? input.alert : "clear";
  const start =
    alert !== "clear" && Number.isFinite(input?.start) ? Number(input.start) : null;
  const messages = (Array.isArray(input?.messages) ? input.messages : [])
    .filter((m) => m && typeof m.text === "string" && Number.isFinite(m.ts))
    .slice(0, 20)
    .map((m) => ({ text: m.text.slice(0, 200), ts: Number(m.ts) }));
  return { alert, start, messages, rev: (prevRev || 0) + 1 };
}

export default async (req) => {
  const store = getStore("school-alerts");

  if (req.method === "GET") {
    const s = (await store.get("current", { type: "json" })) || EMPTY;
    return json({ ...s, now: Date.now() });
  }

  if (req.method === "POST") {
    if (!passwordOk(req.headers.get("x-admin-password"))) {
      await new Promise((r) => setTimeout(r, 700)); // slow down password guessing
      return json({ error: "unauthorized" }, 401);
    }
    let body;
    try {
      body = await req.json();
    } catch {
      return json({ error: "bad request" }, 400);
    }
    // { check: true } is just the sign-in test; it changes nothing.
    if (body?.check) return json({ ok: true });

    const prev = (await store.get("current", { type: "json" })) || EMPTY;
    const next = clean(body?.state, prev.rev);
    await store.setJSON("current", next);
    return json({ ...next, now: Date.now() });
  }

  return json({ error: "method not allowed" }, 405);
};

export const config = { path: "/api/state" };
